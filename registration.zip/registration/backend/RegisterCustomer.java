package com.capgemini.BookStoreProject.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name="customer")
@SequenceGenerator(name = "cutomerseq", initialValue = 300, allocationSize = 5)
public class RegisterCustomer {

	@Id
	@Column(name="customerid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="customerseq")
	private int customerId;
	
	@Column(name="email")
	private String email;
	
	@Column(name="fullname")
	private String fullName;
	
	@Column(name="city")
	private String city;
	
	@Column(name="country")
	private String country;
	
	@Column(name="password")
	private String password;
	
	@Column(name="phonenumber")
	private String phonenumber;
	
	@Column(name="address")
	private String address;
	
	@Column(name="zipcode")
	private int zipcode;

	public RegisterCustomer() {
		super();
		
	}

	public RegisterCustomer(int customerId, String email, String fullName, String city, String country, String password,
			String phonenumber, String address, int zipcode) {
		super();
		this.customerId = customerId;
		this.email = email;
		this.fullName = fullName;
		this.city = city;
		this.country = country;
		this.password = password;
		this.phonenumber = phonenumber;
		this.address = address;
		this.zipcode = zipcode;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	
	
}
